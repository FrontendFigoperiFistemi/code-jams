#include <iostream>
#include <string>
#include <map>
#include <stack>
using namespace std;

#define M  105

int is_pair[M][M];
map<string, int> index;
int people_number;
int group_number;
bool visited[M];
bool rb[M];

void init() {
    memset(is_pair, 0, sizeof(is_pair));
    memset(visited, false, sizeof(visited));
    memset(rb, false, sizeof(rb));
    index.clear();
    people_number = 0;
}
int s2i(string name) {
    map<string, int> :: iterator it = index.find(name);
    if (it == index.end()) {
        people_number ++;
        pair<string, int> temp(name, people_number);
        index.insert(temp);
        return people_number;
    }else {
        return it -> second;    
    }
}
void print() {
    int i, j;
    for (i = 1; i <= people_number; i++) {
        cout << i << ": ";
        for (j = 1; j <= is_pair[i][0]; j++) {
            cout << is_pair[i][j] << " ";
        }    
        cout << endl;
    }    
}
int main(int argc, char *argv[])
{
    int count;
    int count_cout = 1;
    cin >> count;
    while(count--) {
        init();
        int pair_number;
        cin >> pair_number;
        string name1, name2;
        while(pair_number--) {
            cin >> name1 >> name2;
            ++is_pair[s2i(name1)][0];
            is_pair[s2i(name1)][is_pair[s2i(name1)][0]] = s2i(name2);
            ++is_pair[s2i(name2)][0];
            is_pair[s2i(name2)][is_pair[s2i(name2)][0]] = s2i(name1);
        }
        stack<int> s;
        int i;
        bool result = false;
        for (i = 1; i <= people_number; i++) {
            if (!visited[i]) {
                s.push(i);
                visited[i] = true;
                while(!s.empty()) {
                    int temp = s.top();
                    s.pop();
                    int j;
                    for (j=1; j <= is_pair[temp][0]; j++) {
                        if (!visited[is_pair[temp][j]]) {
                            visited[is_pair[temp][j]] = true;
                            rb[is_pair[temp][j]] = !rb[temp];
                            s.push(is_pair[temp][j]);   
                        }else{
                            if (rb[temp] == rb[is_pair[temp][j]]) {
                                result = true;
                                break;    
                            }    
                        }  
                    }
                }       
            }
            if (result) {
                break;    
            }
        }
        cout << "Case #" << count_cout << ": ";
        count_cout ++;
        if (result) {
            cout << "No" << endl;
        }else{
            cout << "Yes" << endl;    
        }
    }
    return 0;
}
