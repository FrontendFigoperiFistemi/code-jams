#include <iostream>
#include <string>
#include <vector>
#include <queue>
#include <map>

using std::string;
using std::vector;
using std::map;


string work() {
  int M;
  std::cin >> M;

  std::map<string, vector<string>> adj;

  for (int i = 0; i < M; ++i) {
    string a, b;
    std::cin >> a >> b;

    adj[a].push_back(b);
    adj[b].push_back(a);
  }

  std::map<string, int> color;

  color[adj.begin()->first] = 1;
  std::queue<string> Q;
  Q.push(adj.begin()->first);

  while (!Q.empty()) {
    string u = Q.front();
    int c = color[u];
    Q.pop();

    for (auto it = adj[u].begin(); it != adj[u].end(); ++it) {
      if (color[*it] == 0) {
        color[*it] = c == 1 ? 2 : 1;
        Q.push(*it);
      } else if (color[*it] == c) {
        return "No";
      }
    }
  }

  return "Yes";
}


int main() {
  int T;
  std::cin >> T;
  for (int i = 1; i <= T; ++i) {
    std::cout << "Case #" << i << ": " << work() << std::endl;
  }
}
