#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<cmath>
#include<algorithm>
#include<map>
#include<queue>
#include<cstdlib>
#include<string>
#include<iostream>
#include<algorithm>
using namespace std;
int set[200];
int d[200][2];
map<string,int>m;
void init(int n)
{
    for(int i=0;i<=n;++i)
        set[i]=i;
}

int find(int x)
{
    if(set[x]==x)return x;
    else
        return set[x]=find(set[x]);
}

void unit(int x,int y)
{
    x=find(x);
    y=find(y);
    if(x<y)set[y]=x;
    else set[x]=y;
}
int main()
{
    freopen("A-small-1-attempt0.in","r",stdin);
    freopen("output.txt","w",stdout);
    int i,j,k,n,t,cas=0;
    scanf("%d",&n);
    for(cas=1;cas<=n;++cas)
    {
        j=0;
        scanf("%d",&t);

        int flag=1;
        for(i=0;i<t;++i)
        {
            string t1,t2;
            cin>>t1>>t2;
            if(m.find(t1)==m.end())m[t1]=j++;
            if(m.find(t2)==m.end())m[t2]=j++;
            d[i][0]=m[t1];
            d[i][1]=m[t2];
        }
        init(j*2);
        for(i=0;i<t;++i)
        {
            int a=d[i][0],b=d[i][1];
            //printf("%d %d, %d %d\n",find(a),find(b),find(a+j),find(b+j));
            if(find(a)==find(b)||find(a+j)==find(b+j))
            {
                flag=0;
            }
            else
            {
                //printf("%d-%d,%d-%d\n",a,b+j,b,a+j);
                unit(set[b+j],find(a));
                unit(set[a+j],find(b));
            }
        }
        printf("Case #%d: ",cas);
        if(flag==0)printf("No\n");
        else printf("Yes\n");
        m.clear();
    }
    return 0;
}
