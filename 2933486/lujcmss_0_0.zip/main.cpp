#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <math.h>
#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <queue>
using namespace std;

int main ()
{
    freopen("/Users/L/Downloads/A-small-1-attempt0.in", "r", stdin);
    freopen("/Users/L/Downloads/A-small-1-attempt0.out", "w", stdout);
    
    int T;
    scanf("%d", &T);
    
    for (int kase = 1; kase <= T; kase++) {
        int m;
        scanf("%d", &m);
        
        vector<int> group(2 * m + 1);
        int tot = 0;
        map<string, int> name;
        name.clear();
        
        vector<vector<int> > next(2 * m + 1);
        vector<int> checked(2 * m + 1);
        for (int i = 0; i < m; i++) {
            string s1, s2;
            cin >> s1 >> s2;
            if (name.count(s1) == 0) {
                checked[tot] = 0;
                name[s1] = tot++;
            }
            if (name.count(s2) == 0) {
                checked[tot] = 0;
                name[s2] = tot++;
            }
            next[name[s1]].push_back(name[s2]);
            next[name[s2]].push_back(name[s1]);
        }
        
        int flag = 1;
        for (int i = 0; i < tot; i++)
            if (!checked[i]) {
                queue<int> list;
                while (!list.empty()) list.pop();
                list.push(i);
                group[i] = 1;
                
                while (!list.empty()) {
                    int now = list.front();
                    list.pop();
                    
                    checked[now] = 1;
                    for (int j = 0; j < next[now].size(); j++) {
                        if (!checked[next[now][j]]) {
                            list.push(next[now][j]);
                            
                            int tmp;
                            if (group[now] == 1) tmp = 2;
                            else tmp = 1;
                            
                            if (group[next[now][j]] == 0) group[next[now][j]] = tmp;
                            else if (group[next[now][j]] != tmp) flag = 0;
                        }
                    }
                }
            }
        
        printf("Case #%d: ", kase);
        if (flag) printf("Yes\n");
        else printf("No\n");
    }
    return 0;
}
