#include <iostream>
#include <math.h>
#include <string>
#include <vector>
#include <map>
#include <queue>


using namespace std;

bool bipartite(map<string, map<string, int> > pairs){
		map<string, map<string,int> >::iterator it, s;
		queue<string> Q;

		map<string, int> visited;
		map<string, int> d;
		map<string, int> group;
		for (it = pairs.begin(); it != pairs.end(); it++){
			visited[it->first] = 0;
			group[it->first] = 0;
		}

		for (s = pairs.begin(); s != pairs.end(); s++){
			if (visited[s->first] == 0){
				visited[s->first] = 1;
				group[s->first] = 1;
				d[s->first] = 0;
				Q.push(s->first);

				string u;
				map<string, int>::iterator v;
					while (!Q.empty()){
						u = Q.front();
						//cout << u << endl;
						for (v = pairs[u].begin(); v != pairs[u].end(); v++){
							if (group[u] == group[v->first]){
								return false;
							}else{
								if (visited[v->first] == 0){
									visited[v->first] = 1;
									d[v->first] = d[u] + 1;
									group[v->first] = 3 - group[u];
									Q.push(v->first);
								}
							}
				
						}
						Q.pop();
					}
			
			}
		}
		return true;

}


// check if the graph is Bipartite 
int main(){

	int T;
	cin >> T;

	int i, j, k;

	for (i=1;i<=T;i++){
		int M;
		cin >> M;
		map<string, map<string, int> > pairs;

		for (j=0;j<M;j++){
			string A, B;
			cin >> A >> B;
			pairs[A][B] = 1;
			pairs[B][A] = 1;
		}

		if (bipartite(pairs)){
			cout << "Case #" << i << ": Yes" << endl;
		}else{
			cout << "Case #" << i << ": No" << endl;
		}
	}

return 0;
}
