#include<stdio.h>
#include<string>
#include<map>
#include<vector>
#include<queue>
using namespace std;

const int MAXSIZE = 1000;
typedef struct Node NODE;

struct Node
{
	//char name;
	int id;
	int color;
	vector<int> neigh_list;
	bool visit;
};

bool JudgeBiGraph(int start, NODE *graph)
{
	queue<int> Myqueue;

	Myqueue.push(start);
	graph[start].color = 0;
	
	while(!Myqueue.empty())
	{
		int gid = Myqueue.front();
		for(int i=0;i<graph[gid].neigh_list.size();i++)
		{
			int neighid = graph[gid].neigh_list[i];
			if(graph[neighid].color==-1)
			{
				graph[neighid].color = (graph[gid].color+1)%2;
				Myqueue.push(neighid);
			}
			else
			{
				if(graph[neighid].color == graph[gid].color)
					return false;
			}
		}
		Myqueue.pop();
	}
	return true;
}

int main()
{
	freopen("C-small-1-attempt0.in", "r", stdin);
    freopen("a.out", "w", stdout);
	int T;
	int M;
	int caseid = 0;
	scanf("%d",&T);
	

	while(caseid<T)
	{
		scanf("%d",&M);
		map<string,int> Mymap;
		NODE graph[MAXSIZE];

		int id = 0;
		for(int i=0;i<M;i++)
		{
			char s1[MAXSIZE],s2[MAXSIZE];
			scanf("%s %s",s1,s2);
			string str_s1(s1),str_s2(s2);
			NODE node1,node2;
			int id1,id2;
			if(Mymap.count(str_s1)==0)
			{
				Mymap[str_s1] = id;
				id1 = id;
				id++;
			}
			else
				id1 = Mymap[str_s1];
			if(Mymap.count(str_s2)==0)
			{
				Mymap[str_s2] = id;
				id2 = id;
				id++;
			}
			else
				id2 = Mymap[str_s2];
			graph[id1].neigh_list.push_back(id2);
			graph[id2].neigh_list.push_back(id1);
		}

		//judge whether it is a bipartigraph
		for(int i=0;i<MAXSIZE;i++)
		{
			graph[i].visit = false;
			graph[i].color = -1;
		}
		if(JudgeBiGraph(0,graph))
			printf("Case #%d: Yes\n",caseid+1);
		else
			printf("Case #%d: No\n",caseid+1);
		caseid++;
	}
	return 0;
}