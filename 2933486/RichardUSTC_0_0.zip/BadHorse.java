import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Queue;
import java.util.Scanner;
import java.util.Set;
import java.util.Vector;

public class BadHorse {
	private int totalTestNum;
	private Scanner sc;
	private int currentTestNum;
	private int currentPairNum;
	private BufferedWriter writer;
	private final int White = 0;
	private final int Black = 1;

	public void solve(String inputFileName, String outputFile)
			throws IOException {
		writer = new BufferedWriter(new FileWriter(outputFile));
		sc = new Scanner(new File(inputFileName));
		totalTestNum = sc.nextInt();
		currentTestNum = 1;
		for (int i = 0; i < totalTestNum; i++) {
			boolean canDivide = sovleOne();
			writer.write("Case #"+currentTestNum+": ");
			if(canDivide){
				writer.write("Yes\n");
			}
			else{
				writer.write("No\n");
			}
			currentTestNum++;
		}
		writer.close();
		sc.close();
	}

	private boolean sovleOne() {
		HashMap<String, Vector<String>> m = new HashMap<String, Vector<String>>();
		currentPairNum = sc.nextInt();
		// read in
		for (int i = 0; i < currentPairNum; i++) {
			String p1 = sc.next("[a-zA-Z_]+");
			String p2 = sc.next("[a-zA-Z_]+");
			if (!m.containsKey(p1)) {
				Vector<String> v = new Vector<String>();
				m.put(p1, v);
			}
			if (!m.containsKey(p2)) {
				Vector<String> v = new Vector<String>();
				m.put(p2, v);
			}
			Vector<String> v1 = m.get(p1);
			Vector<String> v2 = m.get(p2);
			v1.add(p2);
			v2.add(p1);
		}

		// try to divide into two groups
		Set<String> keys = m.keySet();
		HashMap<String, Integer> colorMap = new HashMap<String, Integer>();
		ArrayDeque<String> queue = new ArrayDeque<String>();
		Iterator<String> it = keys.iterator();

		while (it.hasNext()) {
			String p;
			p = it.next();
			while(colorMap.containsKey(p)){
				if(it.hasNext())
					p = it.next();
				else
					return true;
			}
			queue.push(p);
			colorMap.put(p, White);

			while (!queue.isEmpty()) {
				p = queue.pollFirst();
				int color = colorMap.get(p);
				int enemyColor = color == White ? Black : White;
				Vector<String> enemys = m.get(p);
				for (String enemy : enemys) {
					if (colorMap.containsKey(enemy)) {
						int oldColor = colorMap.get(enemy);
						if (oldColor != enemyColor)
							return false;
					} else {
						colorMap.put(enemy, enemyColor);
						queue.push(enemy);
					}
				}
			}
		}
		return true;
	}

	public static void main(String[] args) throws IOException {
		new BadHorse().solve("C:\\Users\\Richard\\Desktop\\input.txt",
				"C:\\Users\\Richard\\Desktop\\output.txt");

	}

}
