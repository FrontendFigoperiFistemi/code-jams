import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int tn = sc.nextInt();
		for (int ti = 1; ti <= tn; ti++) {
			int m = sc.nextInt();
			Map<String, Integer> members = new HashMap<>();
			int memCount = 0;
			List<List<Integer>> table = new ArrayList<>();
			for (int mi = 0; mi < m; mi++) {
				String name1 = sc.next();
				String name2 = sc.next();
				int p1 = -1;
				int p2 = -1;
				if (members.containsKey(name1)) {
					p1 = members.get(name1);
				} else {
					p1 = memCount++;
					members.put(name1, p1);
					table.add(new ArrayList<Integer>());
				}
				if (members.containsKey(name2)) {
					p2 = members.get(name2);
				} else {
					p2 = memCount++;
					members.put(name2, p2);
					table.add(new ArrayList<Integer>());
				}
				table.get(p1).add(p2);
				table.get(p2).add(p1);
			}
			String result = "Yes";
			int[] colors = new int[memCount];
			out: for (int i = 0; i < memCount; i++) {
				if (colors[i] == 0) {
					colors[i] = 1;
					Queue<Integer> q = new LinkedList<>();
					q.add(i);
					while (!q.isEmpty()) {
						int r = q.remove();
						List<Integer> list = table.get(r);
						int c = colors[r];
						for (int x : list) {
							if (colors[x] == c) {
								result = "No";
								break out;
							} else if (colors[x] == 0) {
								colors[x] = -c;
								q.add(x);
							}
						}
					}
				}
			}
			System.out.printf("Case #%d: %s%n", ti, result);
		}
		sc.close();
	}

}
